
const config = { backendEndpoint: "http://13.233.150.184:8081" };

export default config;
